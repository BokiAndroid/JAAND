/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication118;

//Server.java
import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
public class Server extends Frame implements ActionListener

 {
 Label l1,l2,l3,l4;
 TextField t1,t2,t3;
 Button b1,b2;
 Server()
 {
 
   setLayout(null);
   setSize(400,400);
   setVisible(true);
   l1=new Label("Unesi prvi broj:");
   l2=new Label("Unesi drugi broj:");
   l3=new Label("Zbir je:");
   l4=new Label(null);
   t1=new TextField();
   t2=new TextField();
   t3=new TextField();
   b1=new Button("Sabiraj");

   l1.setBounds(110,50,120,20);
   add(l1);
   t1.setBounds(240,50,80,20);
   add(t1);
   l2.setBounds(110,80,130,20);
   add(l2);
   t2.setBounds(240,80,80,20);
   add(t2);
   t3.setBounds(340,80,80,20);
   add(t3);
   l3.setBounds(110,110,100,20);
   add(l3);
   l4.setBounds(220,110,80,20);
   add(l4);
   b1.setBounds(220,150,50,20);
   add(b1);
  
  
   b1.addActionListener(this);
    addWindowListener( new WindowAdapter() {
    public void windowClosing(WindowEvent we)
    {
     System.exit(0);
    }
   });
 try (Socket cn = new Socket("localhost", 201);
 
             BufferedReader bis = new BufferedReader(new InputStreamReader(cn.getInputStream()));
 
             BufferedOutputStream bos = new BufferedOutputStream(cn.getOutputStream());)
 
     {
         
         
 bos.write((t1.getText()).getBytes());
       bos.write((t2.getText()).getBytes());
     
       bos.flush();
 
         String inpstring = bis.readLine();
 
      while(inpstring!=null)
 
      {
 
          System.out.println(inpstring);
 
          inpstring = bis.readLine();
 
          
 

            }
     }
 
     catch(IOException exception)
         
     {
 
         System.out.println(exception.getMessage());
 
     }

//server

  try (ServerSocket sServer = new ServerSocket(201);
 
              Socket cn = sServer.accept();
          
 
              BufferedReader bis = new BufferedReader(new InputStreamReader(cn.getInputStream()));
 
              BufferedOutputStream bos = new BufferedOutputStream(cn.getOutputStream());)
 
      {
       
 
         String racun = bis.readLine();
            while(racun != null && !racun.equals("")) {
             int a = Integer.parseInt(t1.getText());
             int b = Integer.parseInt(t2.getText());
             int sum = a+b;
             System.out.println(sum);
        
             racun = bis.readLine();

   bos.write((sum+"").getBytes());
   t3.setText(Integer.toString(sum));
  

         
 
 
 
          try (FileInputStream fs = new FileInputStream(racun);) {
 
              int readByte;
 
              while ((readByte = fs.read()) != -1) {
 
                  bos.write((byte) readByte);
 
              }
          }
            }
      
            
 
 
 
      } catch (IOException e) {
 
          System.out.println(e.getMessage());

      }
 }
public void actionPerformed(ActionEvent ae)
 {

 }

 public static void main(String[] args)
 {
     Server cn=new Server();
 }
 }