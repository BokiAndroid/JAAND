/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication8;

import java.util.Scanner;

/**
 *
 * @author Poslovni
 */
public class JavaApplication8 {

    /**
     * @param args the command line arguments
     */
 
    public static void main(String[] args) {
     double racun, depozit = 0, podignuo,iznos = 0;double stariIznos = 0;
     int trenutnoStanje = 0;
     String lozinka;
     int brojPokusaja;
     Scanner sc = new Scanner(System.in);
     System.out.println("Molim vas ukucjate broj racuna");
   racun=sc.nextInt();
   System.out.println("Molim vas ukucjate vasu lozinku");
   lozinka=sc.nextLine();

  if(sc.nextLine().equalsIgnoreCase("pera")){

   System.out.println("Vas racun i iznos je" + iznos+stariIznos);
     System.out.println("KOliko novca stavljate na racun");  
     iznos=sc.nextInt();
         double ukupanIznos = iznos+stariIznos;
    System.out.println(" Vas novi iznos je" + ukupanIznos);  
         
  }       

      else{
      
     
      System.out.println("Molim vas ukucjate vasu lozinku ponovo"); 
     
  }
        
           
           
              
           if(sc.nextLine().equalsIgnoreCase("pera")){
             
                 System.out.println("Vas racun i iznos je" + iznos+stariIznos);
     System.out.println("KOliko novca stavljate na racun");  
     iznos=sc.nextInt();
         double ukupanIznos = iznos+stariIznos;
    System.out.println(" Vas novi iznos je" + ukupanIznos);  
         
           }
           else{
     for(brojPokusaja=0;brojPokusaja<=3;brojPokusaja++){
         if(brojPokusaja==1){
          System.out.println("Molim vas ukucjate vasu lozinku ponovo");        
   System.out.println("Blokirana kartica");
    System.out.println("Izaberi broj sa pin kartice");
    int odblokiranje=sc.nextInt();
      if(odblokiranje==1){   
System.out.println("Za odblokiranje racuna pritisnite sifru sa kartice"+odblokiranje);
               System.out.println("Izaberi broj sa pin kartice");

      if(odblokiranje==1){   

      
         System.out.println("Dobrodosli u dopunu racuna");      
             
                 System.out.println("Vas racun i iznos je" + iznos+stariIznos);
     System.out.println("KOliko novca stavljate na racun");  
     iznos=sc.nextInt();
         double ukupanIznos = iznos+stariIznos;
    System.out.println(" Vas novi iznos je" + ukupanIznos);  
  }
           }
    }
}
           }
    }    }

  
    
    
    


    









    



   

